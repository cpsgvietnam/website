
# Vesperr Website

This is a customizable website built with Vesperr theme.

## Features
- Optimized for easy deployment on GitHub Pages and custom domains.

## Deployment
To deploy on GitHub Pages:
1. Commit and push to the `main` branch of your repository.
2. Enable GitHub Pages in repository settings, pointing to the `main` branch.

For custom domains, add your domain to a `CNAME` file in the root of the repository.
    